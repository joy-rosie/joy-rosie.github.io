function hFigure = plotTree(A,strTitle,delta)

    %# Compute all the coordinates needed for the lines and points:
    A = cell2weird(A);
    N = size(A,1);
    xPoints = kron(0:N-1,ones(N,1));
    yPoints = kron(2*(0:N-1)',ones(1,N));
    yPoints = bsxfun(@plus,-yPoints,0:(N-1));
    xLines = [xPoints([1:N+1:N^2-N-1 1:N:N^2-2*N+1]); ...
            xPoints([1:N-1 N:-1:2],N).'];
    yLines = [yPoints([1:N+1:N^2-N-1 1:N:N^2-2*N+1]); ...
            yPoints([1:N-1 N:-1:2],N).'];
    index = find(triu(reshape(1:N^2,N,N)));
    xPoints = xPoints(index);
    yPoints = yPoints(index);
    values = strtrim(cellstr(num2str(A(index),'%1.3e')));
    xTickLabel = cell(1,2*(N+1)+1);
    xTickLabel{1} = '';
    xTickLabel{2} = num2str(0);
    for i = 3:2*(N+1)
        if mod(i,2) == 0
            xTickLabel{i} = num2str((i-2)/2*delta);
%             xTickLabel{i} = [num2str((i-2)/2) '\delta'];
        else
            xTickLabel{i} = '';
        end
    end
    xTickLabel{2*(N+1)+1} = '';
    %# Create the figure:

    hFigure = figure('Color','w');
    hAxes = axes('Parent',hFigure,'XLim',[-0.5 N-0.5],...
               'YLim',[min(yPoints)-1 max(yPoints)+1],...
               'YColor','w','XTickLabel',xTickLabel,'LineWidth',2);
    hold on;
    plot(hAxes,xLines,yLines,'k','LineWidth',2);
    plot(hAxes,xPoints,yPoints,'o','MarkerFaceColor',[0.96 0.96 0.86],...
       'MarkerSize',50,'MarkerEdgeColor','k','LineWidth',2);
    text(xPoints,yPoints,values,'Parent',hAxes,...
       'HorizontalAlignment','center');
    title(strTitle);
    hold off;

end