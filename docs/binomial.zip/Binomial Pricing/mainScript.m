%% INPUTS - WORKS ONLY FOR 5 PERIODS!!!!!!-----

r = 0.02;                       % Annualised risk-free rate
mu = 0.12;                      % Annualised return
sigma = 0.21;                   % Annualised volatility
delta = 1/12;                   % Single period length
T = 3/12;                          % Maturity
S_0 = 1850;                      % Initial stock price
K = 1875;                        % Strike price
optionInfo = cell(3,1);
optionInfo{1} = 'American';     % 'European' or 'American'
optionInfo{2} = 'Call';         % 'Call' or 'Put'
optionInfo{3} = [0;2200];        % Knockout values [0,inf] for no knockout

%% Calculations

% Calculate number of levels in the tree
n = floor(T/delta);

% Calculate u,d
[u,d] = updown(mu,sigma,delta);

% Create recombining stock model
S = initialiseS(S_0,n,u,d);

% Calculate risk neutral probabaility
q = (exp(r*delta)-exp(d))/(exp(u)-exp(d));

% Calculate value of European call option using risk neutral probability 
rnpC = rnp(S,K,r,delta,q,optionInfo);

% Calculate value of European call option using porfolio of stock and bond
% [piC,pi] = portfolio(S,K,r,delta,optionInfo);


%% PLOTTING

% plotTree(S,'Stock Price Model',delta);
plotTree(rnpC,['Option Price Model Using Risk Neutral Pricing with K=' num2str(K)],delta);
% plotTree(piC,['Option Price Model Using Portifolio of Stocks and Bonds with K=' num2str(K)],delta);
