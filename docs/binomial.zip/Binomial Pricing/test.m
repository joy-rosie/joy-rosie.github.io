A = cell2weird(S);
N = size(A,1);
xPoints = kron(0:N-1,ones(N,1))
yPoints = kron(2*(0:N-1)',ones(1,N))
yPoints = bsxfun(@plus,-yPoints,0:(N-1))
  xLines = [xPoints([1:N+1:N^2-N-1 1:N:N^2-2*N+1]); ...
            xPoints([1:N-1 N:-1:2],N).']
  yLines = [yPoints([1:N+1:N^2-N-1 1:N:N^2-2*N+1]); ...
            yPoints([1:N-1 N:-1:2],N).']

% [A,B] = meshgrid(0:2:2*4)
% 
% bsxfun(@plus,-B,0:4)