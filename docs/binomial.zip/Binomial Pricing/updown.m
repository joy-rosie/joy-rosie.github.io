function [u,d] = updown(mu,sigma,delta)
    % Calculates u,d 
    
    u = mu*delta + sigma*sqrt(delta);
    d = mu*delta - sigma*sqrt(delta);

end

