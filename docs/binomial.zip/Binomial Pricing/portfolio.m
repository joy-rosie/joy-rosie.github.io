function [piC,pi] = portfolio(S,K,r,delta,optionInfo)
    % Calculate value of portfolio of stocks and bonds
    
    n = size(S,2) -1;
    
    % Initialise recombining binomial trees for option and portfolio
    pi = mktree(n+1,2);
    piC = mktree(n+1,1);
    
    k = size(piC{n+1},2);
    
    % Calculate the values of the option in the last level
    for i = 1:k
        piC{n+1}(i) = max(S{n+1}(i)-K,0);
    end
    
    for i = 1:n
        k = size(pi{n+1-i},2);
        for j = 1:k
            % Calculate delta by delta = (C_u - C_d) / (S_u - S_d)
            pi{n+1-i}(1,j) = (piC{n+2-i}(j+1)- piC{n+2-i}(j))/...
                (S{n+2-i}(j+1)- S{n+2-i}(j));
            % Calculate beta by beta = e^(-rd)*(delta*S_u - C_u)
            pi{n+1-i}(2,j) = exp(-r*delta)*(pi{n+1-i}(1,j)*S{n+2-i}(j+1)...
                -  piC{n+2-i}(j+1));
            % Calculate option value using C_i,j = delta*S_i,j - beta
            piC{n+1-i}(j) = pi{n+1-i}(1,j)*S{n+1-i}(j) - pi{n+1-i}(2,j);
        end
    end

end

