function [C] = rnp(S,K,r,delta,q,optionInfo)
    % Calculate option value in our recombining binomial model for each
    % node
    
    C = S;
    
    n = size(C,2)-1;
   
    k = size(C{n+1},2);
    
    % Calculate the values of the option in the last level
    for i = 1:k
        % Check if knocked out
        if S{n+1}(i) > optionInfo{3}(2) || S{n+1}(i) < optionInfo{3}(1)
            C{n+1}(i) = 0;
%             disp([num2str(n+1) num2str(i)]);
        else
            % Otherwise calculate value
            C{n+1}(i) = max(S{n+1}(i)-K,0);
            % Check if exercise is better for American
            if strcmp(optionInfo{1},'American') == 1
                if S{n+1}(i)-K > C{n+1}(i)
                    C{n+1}(i) = S{n+1}(i)-K;
                end
            end
        end    
    end
    
    % Calculate the values of the option in the previous levels
    for i = 1:n
        k = size(C{n+1-i},2);
        for j = 1:k
            % Check if knocked out
            if S{n+1-i}(j) > optionInfo{3}(2) ||...
                    S{n+1-i}(j) < optionInfo{3}(1)
                C{n+1-i}(j) = 0;
            else
                % Otherwise calculate value
                % Uses C_i,j = e^(-r\delta)*(q*C_i+1,j+1 + (1-q)*C_i+1,j)
                C{n+1-i}(j) = exp(-r*delta)*...
                    (q*C{n+2-i}(j+1)+(1-q)*C{n+2-i}(j));
                % Check if exercise is better for American
                if strcmp(optionInfo{1},'American') == 1
                    if S{n+1-i}(j)-K > C{n+1-i}(j)
                        C{n+1-i}(j) = S{n+1-i}(j)-K;
                    end
                end
            end
        end
    end


end

