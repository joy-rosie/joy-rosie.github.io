function [B] = cell2weird(A)
    n = size(A,2);
    
    B = zeros(n);
    
    for i = 1:n
        k = size(A{i},2);
        for j = 1:k
            B(j,i) = A{i}(k-j+1);
        end
    end
    
    
end

