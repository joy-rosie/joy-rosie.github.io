function [S] = initialiseS(S_0,n,u,d)
    % Makes a binomial tree for the values of the stock price
    
    % mktree makes a recombining binomial tree of n+1 levels
    S = mktree(n+1,1);

    % Initial stock price
    S{1} = S_0;

    % Fill in the rest of the stock prices according to the model
    for i = 2:n+1
        k = size(S{i},2);
        for j = 1:k
            S{i}(j) = S{1}*exp( (j-1)*u + (k-j)*d);
        end
    end



end

